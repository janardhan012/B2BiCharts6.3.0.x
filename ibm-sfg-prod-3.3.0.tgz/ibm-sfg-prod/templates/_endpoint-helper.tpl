# (C) Copyright 2019-2025 Syncsort Incorporated. All rights reserved.

{{- define "ibm-b2bi.sfg.url" -}}
{{- $root := . -}}
{{- $protocol := ternary "https" "http" .Values.asi.internalAccess.enableHttps }}
{{- $ingressHost := $root.Values.asi.ingress.internal.host }}
{{- $isIngressEnabled := .Values.ingress.enabled }}
{{- $extAccess := $root.Values.asi.externalAccess }}
{{- $svc := $root.Values.asi.frontendService }}
{{- $ports := $svc.ports }}
{{- $portMap := ternary $ports.https $ports.http (eq $protocol "https") }}
{{- $finalPort := 0 }}
{{- if eq $svc.type "NodePort" }}
{{- $finalPort = $portMap.nodePort }}
{{- else }}
{{- $finalPort = $portMap.port }}
{{- end }}
{{- $url := "" -}}

{{- if $isIngressEnabled -}}
{{ printf "%s://%s" $protocol $ingressHost }}
{{- else if eq (lower $svc.type) "nodeport" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $finalPort ) -}}
{{- end -}}
{{- else if eq (lower $svc.type) "loadbalancer" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $finalPort ) -}}
{{- else if $svc.loadBalancerIP -}}
{{- $url = printf "%s://%s:%d" $protocol $svc.loadBalancerIP (int $finalPort ) -}}
{{- end -}}
{{- end -}}

{{- $url -}}
{{- end -}}



{{- define "ibm-b2bi.api.url" -}}
{{- $root := . -}}
{{- $protocol := ternary "https" "http" $root.Values.api.internalAccess.enableHttps }}
{{- $ingressHost := $root.Values.api.ingress.internal.host }}
{{- $isIngressEnabled := .Values.ingress.enabled }}
{{- $extAccess := $root.Values.api.externalAccess }}
{{- $svc := $root.Values.api.frontendService }}
{{- $ports := $svc.ports }}
{{- $portMap := ternary $ports.https $ports.http (eq $protocol "https") }}
{{- $finalPort := 0 }}
{{- if eq $svc.type "NodePort" }}
{{- $finalPort = $portMap.nodePort }}
{{- else }}
{{- $finalPort = $portMap.port }}
{{- end }}
{{- $url := "" -}}

{{- if $isIngressEnabled -}}
{{ printf "%s://%s" $protocol $ingressHost }}
{{- else if eq (lower $svc.type) "nodeport" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $finalPort ) -}}
{{- end -}}
{{- else if eq (lower $svc.type) "loadbalancer" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $finalPort ) -}}
{{- else if $svc.loadBalancerIP -}}
{{- $url = printf "%s://%s:%d" $protocol $svc.loadBalancerIP (int $finalPort ) -}}
{{- end -}}
{{- end -}}

{{- $url -}}
{{- end -}}



{{- define "ibm-b2bi.sfgapis.url" -}}
{{- $root := . -}}
{{- $protocol := "https" }}
{{- $ingressHost := $root.Values.api.ingress.internal.host }}
{{- $isIngressEnabled := .Values.ingress.enabled }}
{{- $extAccess := $root.Values.api.externalAccess }}
{{- $svc := $root.Values.api.frontendService }}
{{- $ports := $svc.ports }}
{{- $fg2httpsPort := $ports.fg2https.port }}
{{- $fg2httpsNodePort := $ports.fg2https.nodePort }}
{{- $url := "" -}}

{{- if $isIngressEnabled -}}
{{- $url = printf "%s://%s" $protocol $ingressHost -}}

{{- else if eq (lower $svc.type) "nodeport" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $fg2httpsNodePort) -}}
{{- end -}}

{{- else if eq (lower $svc.type) "loadbalancer" -}}
{{- if $extAccess.address -}}
{{- $url = printf "%s://%s:%d" $protocol $extAccess.address (int $fg2httpsPort) -}}
{{- else if $svc.loadBalancerIP -}}
{{- $url = printf "%s://%s:%d" $protocol $svc.loadBalancerIP (int $fg2httpsPort) -}}
{{- end -}}
{{- end -}}

{{- $url -}}
{{- end -}}

{{- define "ibm-b2bi.grpc.host" -}}
{{- include "sch.config.init" (list . "b2bi.sch.chart.config.values") -}}
{{- printf "%s.%s" (include "sch.names.fullCompName" (list . .sch.chart.components.headlessService.name)) .Release.Namespace -}}
{{- end -}}

{{- define "ibm-b2bi.grpc.port" -}}
{{- add (.Values.setupCfg.basePort | int) 89 -}}
{{- end -}}



{{- define "b2bi.identityUrl" -}}

  {{- $svc := .Values.identityService -}}
  {{- $protocol := ternary "https" "http" $svc.application.server.ssl.enabled -}}
  {{- $url := "" -}}

  {{/* 1. INGRESS ENABLED */}}
  {{- if $svc.ingress.enabled }}
      {{- $url = printf "%s://%s" $protocol $svc.ingress.host -}}

  {{/* 2. NODEPORT */}}
  {{- else if and (eq $svc.service.type "NodePort") $svc.service.externalIP }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.externalIP $svc.service.nodePort -}}

  {{/* 3a. LOADBALANCER with externalIP */}}
  {{- else if and (eq $svc.service.type "LoadBalancer") $svc.service.externalIP }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.externalIP $svc.service.externalPort -}}

  {{/* 3b. LOADBALANCER fallback loadBalancerIP */}}
  {{- else if eq $svc.service.type "LoadBalancer" }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.loadBalancerIP $svc.service.externalPort -}}
  {{- end }}

  {{- $url -}}

{{- end }}
