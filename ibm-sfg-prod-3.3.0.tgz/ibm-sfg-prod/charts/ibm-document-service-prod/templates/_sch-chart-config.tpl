# (C) Copyright 2023 Syncsort Incorporated. All rights reserved.

{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)

_sch-chart-config.tpl is a config file for the chart to specify additional 
values and/or override values defined in the sch/_config.tpl file.
 
*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "documentSvc.sch.chart.config.values" -}}
sch:
  chart:
    appName: "document-service"
    components:
      documentSvcApp: 
        name: "document-service"
      appInstance:
        name: "document"
      configmap:
        name: "app-config"
      preinstallJob:
        name: "preinstall-job"
      dashboard:
        name: "grafana"
      defaultNetworkPolicy:
        name: "default-network-policy"
      appLogsPVC:
        name: {{ .Values.appLogsPVC.name | default "logs" }}
      ibmDefaultPullSecret:
        name: "ibm-entitlement-key"
    labelType: "prefixed"
    config:
        ciphers: "TLS_AES_256_GCM_SHA384,TLS_AES_128_GCM_SHA256,TLS_CHACHA20_POLY1305_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256,TLS_DHE_DSS_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_DSS_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_DHE_RSA_WITH_AES_256_CBC_SHA256,TLS_DHE_DSS_WITH_AES_256_CBC_SHA256,TLS_DHE_RSA_WITH_AES_128_CBC_SHA256,TLS_DHE_DSS_WITH_AES_128_CBC_SHA256,TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384,TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256,TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_DHE_RSA_WITH_AES_256_CBC_SHA,TLS_DHE_DSS_WITH_AES_256_CBC_SHA,TLS_DHE_RSA_WITH_AES_128_CBC_SHA,TLS_DHE_DSS_WITH_AES_128_CBC_SHA,TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA,TLS_ECDH_RSA_WITH_AES_256_CBC_SHA,TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA,TLS_ECDH_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_GCM_SHA384,TLS_RSA_WITH_AES_128_GCM_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_EMPTY_RENEGOTIATION_INFO_SCSV,TLS_RSA_WITH_AES_256_CBC_SHA256"
    document:
      ingress:
        nginx.ingress.kubernetes.io/rewrite-target: /
        nginx.ingress.kubernetes.io/secure-backends: "true"
      metering:
        productID: {{ template "documentSvc.metering.productId" . }}
        productName: {{ template "documentSvc.metering.productName" . }}
        productVersion: {{ template "documentSvc.metering.productVersion" . }}
        productMetric: {{ template "documentSvc.metering.productMetric" . }}
      nonMetering:
        nonChargeableProductMetric: "FREE"
      nodeAffinity:
        nodeAffinityRequiredDuringScheduling:
          operator: In
          values:
          - amd64
          - ppc64le
        nodeAffinityPreferredDuringScheduling:
          amd64:
            weight: 3
            operator: In
            key: beta.kubernetes.io/arch
      spec:
        serviceAccountName: my-service-account
      podSecurityContext:
        securityContext:
          {{- if ge (.Capabilities.KubeVersion.Minor|int) 24 }}
          seccompProfile:
            type: RuntimeDefault
          {{- end }}
          privileged: false
          readOnlyRootFilesystem: false
          allowPrivilegeEscalation: false
          {{- if .Values.security.runAsUser }}
          runAsUser: {{ .Values.security.runAsUser }}
          {{- end }}
          capabilities:
            drop:
            - ALL
      podSecurityContextTest:
        runAsNonRoot: true
        {{- if ge (.Capabilities.KubeVersion.Minor|int) 24 }}
        seccompProfile:
          type: RuntimeDefault
        {{- end }}
        {{- if .Values.security.supplementalGroups }}
        supplementalGroups: {{ .Values.security.supplementalGroups }}
        {{- end }}
            {{- if .Values.security.fsGroup }}
        fsGroup: {{ .Values.security.fsGroup }}
            {{- end }}
            {{- if .Values.security.fsGroupChangePolicy }}
        fsGroupChangePolicy: {{ .Values.security.fsGroupChangePolicy }}
            {{- end }}
      specSecurityContext:
        securityContext:
          runAsNonRoot: true
          {{- if .Values.security.runAsUser }}
          runAsUser: {{ .Values.security.runAsUser }}
          {{- end }}
          {{- if .Values.security.runAsGroup }}
          runAsGroup: {{ .Values.security.runAsGroup }}
          {{- end }}
          {{- if .Values.security.fsGroup }}
          fsGroup: {{ .Values.security.fsGroup }}
          {{- end }}
          {{- if .Values.security.supplementalGroups }}
          supplementalGroups: {{ .Values.security.supplementalGroups }}
          {{- end }}
      helmTestPodSecurityContext:
        securityContext:
          {{- if ge (.Capabilities.KubeVersion.Minor|int) 24 }}
          seccompProfile:
            type: RuntimeDefault
          {{- end }}
          privileged: false
          readOnlyRootFilesystem: false
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
{{- end -}}
