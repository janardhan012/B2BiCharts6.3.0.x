### IBM Sterling Identity Server v1.0.1.1

### Introduction

IBM Sterling Identity Server is a centralized software platform that provides authentication and authorization services for multiple applications and services using open standards like OAuth 2.0 and OpenID Connect (OIDC).

To find out more, see IBM Sterling Identity Server documentation
https://www.ibm.com/us-en/marketplace/b2b-gateway-software
.

### Chart Details

This sub-chart is deployed by SFG/PEM charts on a container management platform with the following resources:

### Deployments

Identity Application Server with 1 replica by default


### Services

Identity service – Provides access to Identity Server APIs and authentication endpoints with a consistent IP address and hostname

Prerequisites

Red Hat OpenShift Container Platform

    Version 4.19.0 or later fixes
    Version 4.20.0 or later fixes
    Version 4.21.0 or later fixes
    Version 4.22.0 or later fixes

Kubernetes version >= 1.33 and <= 1.36

Helm version >= 3.21.x

Ensure that the docker images for Identity Service from the IBM Entitled Registry are downloaded and pushed to an image registry accessible to the cluster.

Ensure that SFG/PEM must enable the Identity Service for integrated authentication.

Provide external resource artifacts such as database driver JARs, keystores, truststores, and configuration files using one of the following methods:
a. Init container for resources: When resourcesInit.enabled is true, build an init container image bundled with required resource artifacts, and configure it under the resourcesInit.image section.
b. Persistent Volume for resources: When appResourcesPVC.enabled is true, create a persistent volume for application resources with access mode ReadOnlyMany and place the artifacts in the mapped volume.

Only one method (init container or persistent volume) should be used at a time.

When logs.enableAppLogOnConsole is true, logs are redirected to the application console.

Create custom network policies to enable required ingress and egress endpoints for integration with external identity providers (for example, LDAP, SAML, or OAuth servers).

Use the same SFG/PEM secret to pull images from a private registry.

If applicable, create secrets with confidential certificates (for database, LDAP, or SSO integration) using:

kubectl create secret generic <secret-name> --from-file=/path/to/<certificate>


For new database deployments, set dataSetup.enable=true to automatically create required schema tables and metadata for the Identity Server.

### Installation against a pre-loaded database

When installing against a database that already contains the Sterling Identity Server schema and metadata, set dataSetup.enable=false to avoid re-creating tables or overwriting existing configuration.

### Creating a Role Based Access Control (RBAC)

If you are deploying the application in a namespace other than default, create appropriate RBAC with cluster-admin or equivalent role.

Sample RBAC for the default service account in <namespace>:

kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-identity-role-<namespace>
  namespace: <namespace>
rules:
  - apiGroups: ['route.openshift.io']
    resources: ['routes','routes/custom-host']
    verbs: ['get', 'watch', 'list', 'patch', 'update']
  - apiGroups: ['','batch']
    resources: ['secrets','configmaps','persistentvolumes','persistentvolumeclaims','pods','services','cronjobs','jobs']
    verbs: ['create', 'get', 'list', 'delete', 'patch', 'update']

---
kind: RoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-identity-rolebinding-<namespace>
  namespace: <namespace>
subjects:
  - kind: ServiceAccount
    name: default
    namespace: <namespace>
roleRef:
  kind: Role
  name: ibm-identity-role-<namespace>
  apiGroup: rbac.authorization.k8s.io

Pod Security Requirements

With Kubernetes v1.25+, Pod Security Policy (PSP) API is removed and replaced by Pod Security Admission (PSA). Identity Server is compatible with the restricted security level defined in Kubernetes Pod Security Standards.

For older Kubernetes (<1.25) clusters still using PSPs, configure either:

A predefined restricted PSP, or

A custom PSP created by your cluster administrator.

Example PSP based on IBM’s restricted template can be applied if required.

* Predefined PodSecurityPolicy name: [`ibm-restricted-psp`](https://ibm.biz/cpkspec-psp)
 
- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom PodSecurityPolicy based on IBM restricted PSP.
  - Custom PodSecurityPolicy definition:

    ```
    
    apiVersion: policy/v1beta1
    kind: PodSecurityPolicy
    metadata:
      name: "ibm-Identity-psp"
      labels:
        app: "ibm-Identity-psp"
      
    spec:
      privileged: false
      allowPrivilegeEscalation: false
      hostPID: false
      hostIPC: false
      hostNetwork: false
      allowedCapabilities:
      requiredDropCapabilities:
      - ALL
      allowedHostPaths:
      runAsUser:
        rule: MustRunAsNonRoot
      runAsGroup:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      seLinux:
        rule: RunAsAny
      supplementalGroups:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      fsGroup:
        rule: MustRunAs  
        ranges:
        - min: 1
          max: 4294967294
      volumes:
      - configMap
      - emptyDir
      - projected
      - secret
      - downwardAPI
      - persistentVolumeClaim
      - nfs
      forbiddenSysctls:
      - '*' 
    ```

  - Custom Role for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: Role
    metadata:
      name: "ibm-Identity-psp"
      labels:
        app: "ibm-Identity-psp"
    rules:
    - apiGroups:
      - policy
      resourceNames:
      - "ibm-Identity-psp"
      resources:
      - podsecuritypolicies
      verbs:
      - use
    ```

  - Custom Role binding for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-Identity-psp"
      labels:
        app: "ibm-Identity-psp"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-Identity-psp"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```

### SecurityContextConstraints Requirements

Red Hat OpenShift provides a pre-defined or default set of SecurityContextConstraints (SCC). These SCCs are used to control permissions for pods. These permissions include actions that a pod can perform and what resources it can access. You can use SCCs to define a set of conditions that a pod must run with to be accepted into the system. Refer to OpenShift [`Managing Security Context Constraints`](https://docs.openshift.com/container-platform/4.11/authentication/managing-security-context-constraints.html#default-sccs_configuring-internal-oauth) documentation for more details on the default SCCs. This chart is compatible with both restricted and resticted-v2 (added in OpenShift v4.11) default SCCs and does not require a custom SCC to be defined explicity.

For OpenShift, choose either a predefined SCC or have your cluster administrator create a custom SCC for you as per the security profile and policies adopted for all OpenShift deployments. This chart is compatible with most restrictive security context constraints.
Below is an optional custom SCC definition based on the IBM restricted SCC.

* Predefined SecurityContextConstraints name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc)

- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom SCC based on IBM restricted SCC.

  - Custom SecurityContextConstraints definition:

    ```
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata: 
      name: ibm-Identity-scc
      labels:
       app: "ibm-Identity-scc"
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    privileged: false
    allowPrivilegeEscalation: false
    allowPrivilegedContainer: false
    allowedCapabilities: 
    allowedFlexVolumes: []
    allowedUnsafeSysctls: []
    defaultAddCapabilities: []
    defaultAllowPrivilegeEscalation: false
    forbiddenSysctls:
      - "*"
    fsGroup:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - ALL
    runAsUser:
      type: MustRunAsRange
    # This can be customized for your host machine
    seLinuxContext:
      type: MustRunAs
    # seLinuxOptions:
    #   level:
    #   user:
    #   role:
    #   type:
    supplementalGroups:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    # This can be customized for your host machine
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
    - nfs
    priority: 0
    ```

    - Custom Role for the custom SecurityContextConstraints:
    
    ```
    apiVersion: rbac.authorization.k8s.io/v1
	  kind: Role
	  metadata:
     name: "ibm-Identity-scc"
     labels:
      app: "ibm-Identity-scc" 
	  rules:
	  - apiGroups:
  	  - security.openshift.io
  	  resourceNames:
      - "ibm-Identity-scc"
      resources:
      - securitycontextconstraints
      verbs:
      - use
    
    ```

    - Custom Role binding for the custom SecurityContextConstraints:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-Identity-scc"
      labels:
        app: "ibm-Identity-scc"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-Identity-scc"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```
## Network Policy

  For Certified Container deployments, few default network policies are created out of the box as per mandatory security guidelines. By default all ingress and egress traffic are denied with few additional policies to allow communication within cluster and on ports configured in the helm charts configuration. 
  Additionally custom ingress and egress policies can be configured in values yaml to allow traffic from and to specific external service endpoints.

  Note: By default all ingress and egress traffic from or to external services are denied. You will need to create custom network policies to allow ingress and egress traffic from or to services outside of the cluster like database, MQ, protocol adapter endpoints, any other third party service integration and so on.

  Out of the box Ingress policies
  *	Deny all ingress traffic
  *	Allow ingress traffic from all pods in the current namespace in the cluster
  *	Allow ingress traffic on the additional configured ports in helm values
  
  Out of the box Egress policies
  *	Deny all egress traffic
  *	Allow egress traffic within the cluster

## Resources Required

The following table describes the default usage and limits per pod

Pod                                       | Memory Requested  | Memory Limit | CPU Requested | CPU Limit
------------------------------------------| ------------------|--------------| --------------|----------
Identity Server pod                       |       2 Gi        |     2 Gi     |      2        |    2


## Pre-install steps

Before installing the chart to your cluster, the cluster admin must perform the following pre-install steps.

* Create a namespace
* Create a ServiceAccount
    ```
    apiVersion: v1
    kind: ServiceAccount
    metadata: 
      name: {{ sa_name }}-nginxref-nginx
    imagePullSecrets:
    - name: sa-{{ NAMESPACE }}
    ```

If you use the custom security configuration provided here, you must specify messagesight-sa as the service account for your charts.


## Installing the Chart
* Verify SFG/PEM helm charts must have Identity Service sub charts present into the SFG/PEM charts location(ibm-Identity-service-prod) for installation of Identity Service.
* Prepare a custom values.yaml file based on the configuration section.
* It's sub-charts, so it will install  with SFG/PEM charts installation.

> **Tip**: List all releases using `helm list`

* Generally teams have subsections for : 
   * Verifying the Chart
   * Uninstalling the Chart

### Verifying the Chart
See the instruction (from NOTES.txt within chart) after the helm installation completes for chart verification. The instruction can also be viewed by running the command: helm status my-release --tls.

### Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```bash
$ helm delete my-release --purge --tls
```

The command removes all the Kubernetes components associated with the chart and deletes the release.  If a delete can result in orphaned components include instructions with additional commands required for clean-up.  

For example :

When deleting a release with stateful sets the associated persistent volume will need to be deleted.  
Do the following after deleting the chart release to clean up orphaned Persistent Volumes.

```console
$ kubectl delete pvc -l release=my-release
```

### Cleanup any pre-reqs that were created
If cleanup scripts were included in the pak_extensions/post-delete directory; run them to cleanup namespace and cluster scoped resources when appropriate.

## Configuration
### The following table lists the configurable parameters for the Identity sub-chart

Parameter                                      | Description                                                          | Default 
-----------------------------------------------| ---------------------------------------------------------------------| -------------
`license`                                      | Accept Identity license                                              | `false`
`replicaCount`                                 | Identity service deployment replica count                            | 1
`image.repository`                             | Repository for Identity docker images                                     | 
`image.tag          `                          | Docker image tag                                                     | `1.0.1.1`
`image.digest          `                       | Docker image digest. Takes precedence over tag                       | 
`image.pullPolicy`                             | Pull policy for repository                                           | `IfNotPresent`
`image.pullSecret `         			       | Pull secret for repository access                                    | `ibm-entitlement-key`
`arch.amd64`                                   | Specify weight to be used for scheduling for architecture amd64      | `2 - No Preference`
`arch.ppc64le`                                 | Specify weight to be used for scheduling for architecture ppc64le    | `2 - No Preference`
`arch.s390x`                                   | Specify weight to be used for scheduling for architecture s390x      | `2 - No Preference`
`serviceAccount.name`                          | Existing service account name                                        | `default`
`persistence.enabled`                          | Enable storage access to persistent volumes                          | true
`persistence.useDynamicProvisioning`           | Enable dynamic provisioning of persistent volumes                    | false 
`resourcesInit.enabled`                        | Enable resource init containers                                      | true
`resourcesInit.image.repository`               | Repository for resource init container images                        |
`resourcesInit.image.tag`                      | Docker image tag                                                     |
`resourcesInit.image.digest`                   | Docker image digest. Takes precedence over tag                       |
`resourcesInit.image.pullPolicy`               | Pull policy for repository                                           | `IfNotPresent`
`resourcesInit.command`                        | Command to be executed in the resource init container                |
`appResourcesPVC.enabled`                      | Enable Application resource storage                                  | false 
`appResourcesPVC.storageClassName`             | Resources persistent volume storage class name                       | ``
`appResourcesPVC.selector.label`               | Resources persistent volume selector label                           | `intent`
`appResourcesPVC.selector.value`               | Resources persistent volume selector value                           | `resources`
`appResourcesPVC.accessMode`                   | Resources persistent volume access mode                              | `ReadOnlyMany`
`appResourcesPVC.size`                         | Resources persistent volume storage size                             | 500 Mi
`appResourcesPVC.preDefinedResourcePVCName`    | Predefined resources persistent volume name                          | 
`appLogsPVC.enabled`                      | Enable Application logs storage                                  | false
`appLogsPVC.storageClassName`                  | Logs persistent volume storage class name                            | ``
`appLogsPVC.selector.label`                    | Logs persistent volume selector label                                | `intent`
`appLogsPVC.selector.value`                    | Logs persistent volume selector value                                | `logs`
`appLogsPVC.accessMode`                        | Logs persistent volume access mode                                   | `ReadWriteMany`
`appLogsPVC.size`                              | Logs persistent volume storage size                                  | 500 Mi
`appLogsPVC.preDefinedLogsPVCName`             | Predefined logs persistent volume name                               |   
`appDocumentsPVC.enabled`                      | Enable Application document storage                                  | false
`appDocumentsPVC.storageClassName`             | Documents persistent volume storage class name                       | ``
`appDocumentsPVC.selector.label`               | Documents persistent volume selector label                           | `intent`
`appDocumentsPVC.selector.value`               | Documents persistent volume selector value                           | `storage`
`appDocumentsPVC.accessMode`                   | Documents persistent volume access mode                              | `ReadWriteMany`
`appDocumentsPVC.size`                         | Documents persistent volume storage size                             | 1Gi
`appDocumentsPVC.preDefinedDocumentPVCName`    | Predefined document persistent volume name                           |
`extraPVCs`                                    | Extra volume claims shared across all deployments                    | 
`extraSecrets`                                 | Extra secrets. `mountAsVolume` if `true`, the secrets will be mounted as a volume on `/ibm/resources/<secret-name>` folder else they will be exposed as environment variables. | 
`security.supplementalGroups`                  | Supplemental group id to access the persistent volume                | 0
`security.fsGroup`                             | File system group id to access the persistent volume                 | 0
`security.runAsUser`                           | The User ID that needs to be run as by all containers                | 
`security.runAsGroup`                           | The Group ID that needs to be run as by all containers              | 
`application.server.port`               | Application Server port                      | 9443
`application.server.ssl.enabled`               | Enable SSL for application server                      | true
`application.server.ssl.tlsSecretName`               | TLS secret name holding certificate/key pair                       | 
`application.server.ssl.protocol`               | SSL protocl to be used for SSL connection                       | TLS
`application.server.ssl.enabledProtocols`               | List of Protocols to be enabled for SSL connection                       | TLSv1.2,TLSv1.3
`application.server.ssl.skipSniValidation`               | Skip SNI validation                       | true
`application.server.sessionCookieName`               | Session cookie name                       |
`application.token.accessTokenExpire`               | Access token expire time                     |
`application.token.refreshTokenExpire`               | Refresh token expire time                     |
`application.logging.level`               | Logging level                     | "ERROR"
`application.logging.configFilePath`               | logging config file.                     |

`application.logLevel`                           | DataSetup log level                                                  | INFO 
`application.dbVendor`                             | Database vendor - DB2/Oracle/MSSQL                                   | 
`application.dbHost`                               | Database host                                                        | 
`application.dbPort`                               | Database port                                                        | 
`application.dbDrivers`                            | Database driver jar name                                             | 
`application.dbSecret`                             | Database user secret name                                            | 
`application.clientApplicationName`    | The type of client application this identity service is for. Must be either pem or sfg                                   | pem
`application.corsAllowedOrigins`       | Configures the CORS allowed origins. Use "*" to allow all origins or specify a specific origin                        | "*"
`application.clientSecret`             | Client Secret	                                  | "identity-client-secret"
`application.clientEndpoints.name`     | Name for the client application endpoint                          | "PEM/SFG"
`application.clientEndpoints.url`      | The full URL of the client application endpoint                  | false
`application.dbSslVersion`                           | SSL Version for database connection                               |
`application.dbTruststore`                         | Database truststore file name including it's path relative to the mounted resources volume location. When `dbTruststoreSecret` is mentioned, provide the name of the key holding the certificate data.                         | 
`application.dbTruststoreSecret`                  | Name of the Database truststore secret containing the certificate, if applicable.                      | 
`application.dbKeystore`                          | Database keystore file name including it's path relative to the mounted resources volume location, if applicable. When `dbKeystoreSecret` is mentioned, provide the name of the key holding the certificate data.                         |
`application.dbKeystoreSecret`                    | Name of the Database keystore secret containing the certificate, if applicable.                       | 
`application.MSSQL_HOST_NAME_IN_CERTIFICATE`                      | MSSQL Database configuration to check Host Name in Certificate                     | 
`application.MSSQL_TRUST_SERVER_CERTIFICATE`                | MSSQL Database configuration trust server certificate                   | true
`application.MSSQL_ENCRYPT`                    | MSSQL Database configuration for encrypt.                     | true
`logs.enableAppLogOnConsole`                   | Enable application logs redirection to pod console                   | `true` 
`service.type`                                 | Type of Kubernetes Service (ClusterIP, NodePort, LoadBalancer)        | ClusterIP
`service.externalPort`                         | External port exposed by the service                                  | 443
`service.nodePort`                             | NodePort value used when service.type = NodePort                      | 
`service.externalIP`                           | External IP used when the service type is NodePort or LoadBalancer. 
`service.loadBalancerIP`                       | LoadBalancer static IP when service.type = LoadBalancer               |
`service.annotations`                          | Additional annotations for the Kubernetes Service                     | {}
`ingress.enabled`                               | Enable Kubernetes/OpenShift ingress or route resource                 | false
`ingress.host`                                  | Hostname for the ingress or route                                     |
`ingress.tls.enabled`                           | Enable TLS for ingress (Kubernetes only)                              | false
`ingress.tls.secretName`                        | TLS secret name used for ingress                                      |
`ingress.controller`                            | Ingress controller class (e.g., nginx)                                | nginx
`ingress.annotations`                           | Additional annotations for the ingress/route resource                 | {}
`ingress.labels`                                | Additional labels for the ingress/route resource                      | {}
`replicaCount`                             | Identity Catalog Server deployment replica count         | 1
`env.jvmOptions`                           | JVM options for  server                  |
`env.extraEnvs`                            | Provide extra environment variables for Identity                          | 
`server.port`                              | Server port for                           | 2809
`server.ssl.enabled`                       | SSL configuration                          | false
`resources`                                | CPU/Memory/Ephemeral Storage resource requests/limits                                  | 
`livenessProbe.initialDelaySeconds`        | Livenessprobe initial delay in seconds                               | 60
`livenessProbe.timeoutSeconds`             | Livenessprobe timeout in seconds                                     | 10
`livenessProbe.periodSeconds`              | Livenessprobe interval in seconds                                    | 60
`readinessProbe.initialDelaySeconds`       | ReadinessProbe initial delay in seconds                              | 60
`readinessProbe.timeoutSeconds`            | ReadinessProbe timeout in seconds                                    | 10
`readinessProbe.periodSeconds`             | ReadinessProbe interval in seconds                                   | 60
`readinessProbe.command`                   | ReadinessProbe command to be executed                                |
`readinessProbe.arg`                       | ReadinessProbe command arguments                                     |
`autoscaling.enabled`                      | Enable autoscaling                                                   | false
`autoscaling.minReplicas`                  | Minimum replicas for autoscaling                                     | 1
`autoscaling.maxReplicas`                  | Maximum replicas for autoscaling                                     | 2
`autoscaling.targetCPUUtilizationPercentage`| Target CPU utilization                                              | 60
`ingress.internal.host`                    | Internal Host name for ingress resource	                          |
`ingress.internal.tls.enabled`             | Enable TLS for ingress                                               | true
`ingress.internal.tls.secretName`          | TLS secret name                                                      |
`ingress.internal.extraPaths`              | Extra paths for ingress resource                                     | 
`ingress.external.host`                    | External Host name for ingress resource	                          |
`ingress.external.tls.enabled`             | Enable TLS for ingress                                               | true
`ingress.external.tls.secretName`          | TLS secret name                                                      |
`ingress.external.extraPaths`              | Extra paths for ingress resource                                     |      
`test.image.repository`                        | Repository for docker image used for helm test and cleanup           | 'ibmcom/opencontent-common-utils'
`test.image.tag          `                     | helm test and cleanup docker image tag                               | `1.1.70`
`test.image.digest          `                  | helm test and cleanup docker image digest. Takes precedence over tag |
`test.image.pullPolicy`                        | Pull policy for helm test image repository                           | `IfNotPresent`




A subset of the above parameters map to the env variables defined in [(PRODUCTNAME)](PRODUCTDOCKERURL). For more information please refer to the [(PRODUCTNAME)](PRODUCTDOCKERURL) image documentation.

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

> **Tip**: You can use the default values.yaml

## Storage
* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations
* Deployment limits - can you deploy more than once, can you deploy into different namespace
* Identity Service sub-chart will be deployed by SFG/PEM charts. 
* Identity catalog pod replica counts should be odd numbers only.
* Identity Catalog pod cannot be auto scaled, it needs to be handled using replica counts only. 

Note: 
The application installation will automatically create some default internal routes on 
*	Internal Information route host for these web contexts – /login


## Documentation
* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.
