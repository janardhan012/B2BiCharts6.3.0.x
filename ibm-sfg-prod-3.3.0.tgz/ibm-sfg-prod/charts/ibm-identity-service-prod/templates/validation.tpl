# (C) Copyright 2025 Precisely Incorporated. All rights reserved.

{{/*
----------------------------------------------------
 Helper Functions
----------------------------------------------------
*/}}

{{/* Check if a string is non-empty */}}
{{- define "identityservice.stringValidation" -}}
  {{- if and . (ne (trim .) "") -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}


{{/* Check if value is an integer */}}
{{- define "identityservice.integerValidation" -}}
  {{- if regexMatch "^[0-9]+$" (toString .) -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{/* Check if PVC size is valid (must end with Mi or Gi) */}}
{{- define "storageSizeValidation" -}}
  {{- if regexMatch "^[0-9]+(Mi|Gi)$" (toString .) -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{/* Check mandatory arguments (non-empty) */}}
{{- define "identityservice.mandatoryArgumentsCheck" -}}
  {{- if and . (ne (trim .) "") -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{/* Validate Port Range (1-65535) */}}
{{- define "identityservice.isPortValid" -}}
  {{- $p := int . -}}
  {{- if and (gt $p 0) (lt $p 65536) -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}


{{/*
----------------------------------------------------
 Main Validation Logic
----------------------------------------------------
*/}}
{{- define "identityservice.validateValues" -}}

  {{/* ------------------ License ------------------ */}}
	{{/* Validate license */}}
		{{- if not (kindIs "bool" .Values.license) }}
		{{ fail "license must be set to true or false (boolean)" }}
		{{- else if not .Values.license }}
		{{ fail "You must accept the license agreement by setting license=true" }}
		{{- end }}

{{/* Validate inputs */}}

{{- $result := include "identityservice.integerValidation" .Values.replicaCount -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for .Values.replicaCount" -}}
{{- end -}}


  {{/* ------------------ Image ------------------ */}}
  {{- if eq (include "identityservice.stringValidation" .Values.image.repository) "false" }}
    {{ fail "image.repository must be a non-empty string" }}
  {{- end }}
  {{- if eq (include "identityservice.stringValidation" .Values.image.tag) "false" }}
    {{ fail "image.tag must be a non-empty string" }}
  {{- end }}
  {{- if and (not (empty .Values.image.pullPolicy)) (not (has .Values.image.pullPolicy (list "IfNotPresent" "Always" "Never"))) }}
    {{ fail (printf "image.pullPolicy must be one of: IfNotPresent, Always, Never (found %s)" .Values.image.pullPolicy) }}
  {{- end }}

  {{/* ------------------ Architecture ------------------ */}}
  {{- range $arch, $val := .Values.arch }}
    {{- if eq (include "identityservice.stringValidation" $val) "false" }}
      {{ fail (printf "arch.%s must be a valid string (found %v)" $arch $val) }}
    {{- end }}
  {{- end }}

  {{/* ------------------ Persistence ------------------ */}}
  {{- if not (kindIs "bool" .Values.persistence.enabled) }}
    {{ fail "persistence.enabled must be a boolean" }}
  {{- end }}
  {{- if not (kindIs "bool" .Values.persistence.useDynamicProvisioning) }}
    {{ fail "persistence.useDynamicProvisioning must be a boolean" }}
  {{- end }}

  {{/* ------------------ Resources Init ------------------ */}}
  {{- if not (kindIs "bool" .Values.resourcesInit.enabled) }}
    {{ fail "resourcesInit.enabled must be a boolean" }}
  {{- end }}
  {{- if eq (include "identityservice.stringValidation" .Values.resourcesInit.image.repository) "false" }}
    {{ fail "resourcesInit.image.repository must be a non-empty string" }}
  {{- end }}
  {{- if eq (include "identityservice.stringValidation" .Values.resourcesInit.image.tag) "false" }}
    {{ fail "resourcesInit.image.tag must be a non-empty string" }}
  {{- end }}

  {{/* ------------------ App Resources PVC ------------------ */}}
  {{- if .Values.appResourcesPVC.enabled }}
    {{- if eq (include "storageSizeValidation" .Values.appResourcesPVC.size) "false" }}
      {{ fail (printf "appResourcesPVC.size must be a valid size string with Mi/Gi (found %s)" .Values.appResourcesPVC.size) }}
    {{- end }}
    {{- if and (not (empty .Values.appResourcesPVC.accessMode)) (not (has .Values.appResourcesPVC.accessMode (list "ReadWriteOnce" "ReadOnlyMany" "ReadWriteMany"))) }}
      {{ fail (printf "appResourcesPVC.accessMode must be one of: ReadWriteOnce, ReadOnlyMany, ReadWriteMany (found %s)" .Values.appResourcesPVC.accessMode) }}
    {{- end }}
  {{- end }}

  {{/* ------------------ App Logs PVC ------------------ */}}
  {{- if .Values.appLogsPVC.enabled }}
    {{- if eq (include "storageSizeValidation" .Values.appLogsPVC.size) "false" }}
      {{ fail (printf "appLogsPVC.size must be a valid size string with Mi/Gi (found %s)" .Values.appLogsPVC.size) }}
    {{- end }}
    {{- if and (not (empty .Values.appLogsPVC.accessMode)) (not (has .Values.appLogsPVC.accessMode (list "ReadWriteOnce" "ReadOnlyMany" "ReadWriteMany"))) }}
      {{ fail (printf "appLogsPVC.accessMode must be one of: ReadWriteOnce, ReadOnlyMany, ReadWriteMany (found %s)" .Values.appLogsPVC.accessMode) }}
    {{- end }}
  {{- end }}

  {{/* ------------------ Security ------------------ */}}
  {{- range $i, $gid := .Values.security.supplementalGroups }}
    {{- if eq (include "identityservice.integerValidation" $gid) "false" }}
      {{ fail (printf "security.supplementalGroups[%d] must be an integer (found %v)" $i $gid) }}
    {{- end }}
  {{- end }}
  {{- if and .Values.security.fsGroup (eq (include "identityservice.integerValidation" .Values.security.fsGroup) "false") }}
    {{ fail "security.fsGroup must be an integer" }}
  {{- end }}
  {{- if and .Values.security.runAsUser (eq (include "identityservice.integerValidation" .Values.security.runAsUser) "false") }}
    {{ fail "security.runAsUser must be an integer" }}
  {{- end }}
  {{- if and .Values.security.runAsGroup (eq (include "identityservice.integerValidation" .Values.security.runAsGroup) "false") }}
    {{ fail "security.runAsGroup must be an integer" }}
  {{- end }}

  {{- $isValid := .Values.application.server.ssl.skipSniValidation | toString -}}
  {{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
    {{ fail "Please provide Value for skipSniValidation. Value can be either false or true." }}
  {{- end }}

  {{- $isValid := include "identityservice.integerValidation" .Values.application.token.accessTokenExpire -}}
  {{- if eq $isValid "false" -}}
        {{- fail "Values.application.token.accessTokenExpire is not valid." -}}
  {{- end -}}
  {{- $isValid := include "identityservice.integerValidation" .Values.application.token.refreshTokenExpire -}}
  {{- if eq $isValid "false" -}}
        {{- fail "Values.application.token.refreshTokenExpire is not valid." -}}
  {{- end -}}

  {{- $result := include "identityservice.mandatoryArgumentsCheck" .Values.application.logging.level -}}
  {{- if eq $result "false" -}}
  {{- fail ".Values.application.logging.level cannot be empty." -}}
  {{- else -}}
  {{- $result := .Values.application.logging.level -}}
  {{- if not (or (eq $result "ERROR") (eq $result "INFO") (eq $result "DEBUG") (eq $result "TRACE")) -}}
  {{- fail ".Values.application.logging.level is not valid. Valid values are 'ERROR', 'INFO', 'DEBUG' or 'TRACE'" -}}
  {{- end -}}
  {{- end -}}

  {{/* ------------------ Database ------------------ */}}
  {{- $isValid := .Values.application.dbVendor -}}
  {{- if not ( or (eq $isValid "DB2") (eq $isValid "Oracle") (eq $isValid "MSSQL") (eq $isValid "db2") (eq $isValid "oracle") (eq $isValid "mssql")) -}}
    {{ fail "Please specify dbVendor as one of these supported databases - DB2 | Oracle | MSSQL" }}
  {{- end }}

  {{- $result := include "identityservice.mandatoryArgumentsCheck" .Values.application.dbSecret -}}
  {{- if eq $result "false" -}}
    {{ fail ".Values.application.dbSecret cannot be empty" }}
  {{- end }}

  {{- $isValid := include "identityservice.mandatoryArgumentsCheck" .Values.application.dbHost -}}
  {{- if eq $isValid "false" -}}
    {{ fail "Please specify the dbHost." }}
  {{- end }}

  {{- $isValid := include "identityservice.isPortValid" .Values.application.dbPort -}}
  {{- if eq $isValid "false" -}}
    {{ fail "Please specify the dbPort correctly." }}
  {{- end }}

  {{- $isValid := include "identityservice.mandatoryArgumentsCheck" .Values.application.dbData -}}
  {{- if eq $isValid "false" -}}
    {{ fail "Please specify the dbData." }}
  {{- end }}
  

  {{- $isValid := .Values.application.dbUseSsl | toString -}}
  {{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
    {{ fail "Please provide Value for dbUseSsl. Value can be either false or true." }}
  {{- end }}

  {{- $isValid := .Values.autoscaling.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide value for Values.autoscaling.enabled. Value can be either false or true." -}}
{{- end -}}

{{- $isValid := .Values.autoscaling.enabled | toString -}}
{{- if eq $isValid "true" -}}
        {{- $isValid := include "identityservice.integerValidation" .Values.autoscaling.minReplicas -}}
        {{- if eq $isValid "false" -}}
        {{- fail "Values.autoscaling.minReplicas is not valid." -}}
        {{- end -}}

        {{- $isValid := include "identityservice.integerValidation" .Values.autoscaling.maxReplicas -}}
        {{- if eq $isValid "false" -}}
        {{- fail "Values.autoscaling.maxReplicas is not valid." -}}
        {{- end -}}

        {{- $isValid := include "identityservice.integerValidation" .Values.autoscaling.targetCPUUtilizationPercentage -}}
        {{- if eq $isValid "false" -}}
        {{- fail "Values.autoscaling.targetCPUUtilizationPercentage is not valid." -}}
        {{- end -}}
{{- end -}}

{{- end }}

{{/*
----------------------------------------------------
 Execute Validations on Render
----------------------------------------------------
*/}}
{{- include "identityservice.validateValues" . -}}
